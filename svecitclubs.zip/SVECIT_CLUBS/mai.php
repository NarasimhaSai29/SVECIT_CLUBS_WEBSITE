<?php
$to = "narasimhasai29@gmail.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: knsai208@gmail.com" . "\r\n" .
"CC: narasimhasai29@gmail.com";

mail($to,$subject,$txt,$headers);
?>