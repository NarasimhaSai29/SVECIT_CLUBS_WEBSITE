<html>
<head>
<title>Register for Event</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
</head>
<body bgcolor="cyan">
<div class="container-fluid" style="background-color:yellow;margin-left:400px;width:600px;height:425px;float:left;border:2px dashed blue;">
<form action="iotstustore.php" method="post">
<table align="center" rowspan=5 cellpadding=3 cellspacing=5>
<h1 align="center"><i>Fill Details for registration</i></h1><hr>
<tr><td align="center">Your Name:  </td>
<td align="center"><input type="text" name="name" required></td></tr>
<tr><td align="center">ID number:  </td>
<td align="center"><input type="text" name="id" required></td></tr>
<tr><td align="center">Branch:  </td>
<td align="center"><select name="br" required>
<option> </option>
<option>IT</option>
<option>CSSE</option>
<option>CSE</option>
<option>ECE</option>
<option>EEE</option>
<option>MECH</option>
<option>CIVIL</option>
</select></td></tr>
<tr><td align="center">EventDate:  </td>
<td align="center"><input type="date" name="event" required></td></tr>
<tr><td align="center">Phone No.:  </td>
<td align="center"><input type="text" name="phno" required>
</td></tr>
<tr><td align="center">Email-ID:  </td>
<td align="center"><input type="email"name="em" required></td></tr>
<tr><td align="center"><input type="reset"value="RESET">
</td>
<td align="center"><input type="submit" name="Register" value="REGISTER"></td></tr>
</table>
<br><a href="iot.html">Click Here to go Club Home Page</a>
</form>
</div>
</body>
</html>