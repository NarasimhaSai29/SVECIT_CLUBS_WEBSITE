<html>
<body>
<?php
$v=$_COOKIE['Username'];
$p=$_COOKIE['Password'];
$u=$_POST['uname'];
$a=$_POST['pswd'];
if($v==$u)
{
if($p==$a)
{
echo "<h1 align='center'>Welcome $u </h1>";
echo "<button width='50%'><a href='pceventtrig.php' style='font-size:30px;' target='_parent'>Trigger Event</a></button><br><br>";
echo "<button width='50%'><a href='pcdel.php' style='font-size:30px;' target='_parent'>Delete Event</a></button><br><br>";
echo "<a href='project.html' style='font-size:30px;' target='_parent'>pc club Home</a>";
} 
else {
echo "<script type='text/javascript'>";
echo "alert('Please check Your Password or UserName')";
echo "</script>"; 
echo" <a href='pcfaclogin.php' style='font-size:30px;' target='_parent'>Go to login page</a>";
echo"<a href='project.html' style='font-size:30px;' target='_parent'>pc CLUB Home</a>";} }
else {
echo "<script type='text/javascript'>";
echo "alert('Please check Your Password or Username')";
echo "</script>"; 
echo" <a href='pcfaclogin.php' style='font-size:30px;' target='_parent'>Go to login page</a>";
echo"<a href='project.html' style='font-size:30px;' target='_parent'>pc CLUB Home</a>";}
?> 
</body> 
</html>