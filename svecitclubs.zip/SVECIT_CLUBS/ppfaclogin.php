<?php
setCookie("Username","svecit04",time()+ 50 * 60,"/","",0);
setCookie("Password","svecit04",time()+ 50 * 60,"/","",0); ?>
<html> <head> <title>Faculty Login</title> </head>
<body align="center"> 
<a href="python.html">Click here to go to home page</a>
<form action="ppwel1.php" method="post">
<table align="center" border="0" width="100%" cellspacing="40">
<tr><td align="center">Username<br><input type="text"
name="uname" align="center"></td></tr>
<tr><td align="center">Password<br><input type="password"
name="pswd" ></td></tr>
<tr><td align="center"><input type="submit"
value="Sign-In"></td></tr>
</form>
</table>
</div>
</body>
</html>