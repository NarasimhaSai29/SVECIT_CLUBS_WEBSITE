<html>
<head>
<title>Registered Students</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
</head>
<body align="center" >
<form action="pceventstu.php" method="POST">
<div class="container-fluid">
<button align="left" style="margin-left:0px:left:0px;"><a href='project.html' style='font-size:15px;' target='_parent'>PC CLUB Home</a></button><br><br><br>
<b style="font-size:22px">Event :&nbsp;<input type="date" name="event"><br><br>
<button align="center" type="submit" value="submit" name="submit">SUBMIT</button><br></b>
</div></form>
<?php
if(isset($_POST['submit']))
{
	$ev=$_POST['event'];
	$con=mysqli_connect("localhost","root","","IT");
	$sql="SELECT * from pcstudents where EventOn='$ev'";
	$result=$con->query($sql);
	if($result->num_rows>0)
	{
echo "<table border=1><tr><th>S.No</th><th>Name</th><th>ID</th>
<th>Branch</th><th>Phone</th><th>Email</th></tr>";
$SNo=0;
while($row=$result->fetch_assoc())
{
$SNo=$SNo+1;
echo "<tr><td>".$SNo."</td.><td>".$row['Name']."</td><td>".$row['ID']."</td><td>".$row['Branch']."</td><td>".$row['Phone']."</td><td>".$row['Email']."</td></tr>";
}
echo "</table>";
}
else
{
	echo "No records";
	$con->close();
}
} ?>
</body>
</html>