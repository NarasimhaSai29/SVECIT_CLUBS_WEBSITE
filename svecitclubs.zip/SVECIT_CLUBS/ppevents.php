<html>
<head>
<title>PYTHON CLUB EVENTS</title></head>
<body bgcolor="pink">
<center>
<a href="ppregister.php">Click Here to Register For an Event</a><br></center><br>
<?php 
	$con=mysqli_connect("localhost","root","","IT");
	$sql="SELECT * from ppeventslist";
	$result=$con->query($sql);
	if($result->num_rows>0)
	{
echo "<table border=1 font-size=10px align=center cellspacing='3' cellpadding='20' width=50% height=15%><tr style='font-size:22px;'><th>S.No</th><th>Date</th><th>Event</th>
<th>Target</th><th>Time</th><th>Venue</th></tr>";
$SNo=0;
while($row=$result->fetch_assoc())
{
$SNo=$SNo+1;
echo "<tr><td>".$SNo."</td.><td>".$row['Date']."</td><td>".$row['Event']."</td><td>".$row['Target']."</td><td>".$row['Time']."</td><td>".$row['Venue']."</td></tr>";
}
echo "</table>";
}
else
{
	echo "No records";
	$con->close();
}
 ?>
 </body>
 </html>