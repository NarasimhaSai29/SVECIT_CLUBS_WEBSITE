<?php
	$d=$e=$tg=$t=$v="";
	$d=$_POST['edate'];
	$e=$_POST['ename'];
	$tg=$_POST['targyear'];
	$t=$_POST['time'];
	$v=$_POST['venue'];
	$con=mysqli_connect("localhost","root","","IT");
	if(!$con)
	{
		die("Connection failed:".mysqli_connect_error());
	}
	$re="";
	$ch="INSERT INTO ioteventslist(Date,Event,Target,Time,Venue)VALUES('".$d."','".$e."','".$tg."','".$t."','".$v."')";
	if(mysqli_query($con,$ch))
	{
		echo "<html>";
		echo "<body>";
		echo "<h3 align='center'>Succesfully Stored</h3>";
		echo "<br><a href='ioteventtrig.php' style='font-size:30px;' target='_parent'>Raise another Event</a><br><br>";
		echo "<br><a href='iotfaclogin.php' style='font-size:30px;' target='_parent'>Logout</a><br><br>";
		echo "<br><a href='iot.html' style='font-size:30px;' target='_parent'>Logout and Go to IoT CLUB Home</a>";
		echo "</body>";
		echo "</html>";
	}
	?>