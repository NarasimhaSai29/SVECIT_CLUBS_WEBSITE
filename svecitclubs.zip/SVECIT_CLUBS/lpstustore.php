<?php
	$n=$id=$b=$ev=$ph=$e="";
	$n=$_POST['name'];
	$id=$_POST['id'];
	$b=$_POST['br'];
	$ev=$_POST['event'];
	$ph=$_POST['phno'];
	$e=$_POST['em'];
	$con=mysqli_connect("localhost","root","","IT");
	if(!$con)
	{
		die("Connection failed:".mysqli_connect_error());
	}
	$re="";
	$ch="INSERT INTO lpstudents(Name,ID,Branch,EventOn,Phone,Email)VALUES('".$n."','".$id."','".$b."','".$ev."','".$ph."','".$e."')";
	if(mysqli_query($con,$ch))
	{
		// echo "<html>";
		// echo "<body>";
		echo "<script type='text/javascript'>";
		echo "alert('Succesfully Stored   check your Email for furthur details')";
		echo "</script>";
		echo "<br><a href='logical.html' style='font-size:30px;' target='_parent'>LP CLUB Home</a>";
		// echo "</body>";
		// echo "</html>";
	}
	?>
<?php
$d = $_POST["event"];
$name = $_POST["name"];
$id = $_POST["id"];
$br = $_POST["br"];
$ph = $_POST["phno"];
$email = $_POST["em"];
$r=rand(10000,100000);
$subject = "SVECIT CLUBS";
$txt = "You are successfully registered for an event on $d in SVECIT clubs\n Your Name:$name\nYour ID:$id \nYour Branch is $br\nYour Phone no:$ph\nYour Email:$email \n\nyour regiatration number is $r";
$headers = "From: svecit00@gmail.com@gmail.com" . "\r\n" ;

mail($email,$subject,$txt,$headers);
?>