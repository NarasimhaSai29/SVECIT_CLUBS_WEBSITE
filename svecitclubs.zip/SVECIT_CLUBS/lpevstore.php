<html>
<body>
<a href="logical.html"><button style="padding: 10px 50px; font-size: 20px;">Home</button></a>
<?php
	$d=$e=$tg=$t=$v="";
	$d=$_POST['edate'];
	$e=$_POST['ename'];
	$tg=$_POST['targyear'];
	$t=$_POST['time'];
	$v=$_POST['venue'];
	$con=mysqli_connect("localhost","root","","IT");
	if(!$con)
	{
		die("Connection failed:".mysqli_connect_error());
	}
	$re="";
	$ch="INSERT INTO lpeventslist(Date,Event,Target,Time,Venue)VALUES('".$d."','".$e."','".$tg."','".$t."','".$v."')";
	if(mysqli_query($con,$ch))
	{
		echo "<html>";
		echo "<body>";
		echo "<h3 align='center'>Succesfully Stored</h3>";
		echo "<br><a href='lpeventtrig.php' style='font-size:30px;' target='_parent'>Raise another event</a><br><br>";
		echo "<br><a href='lpfaclogin.php' style='font-size:30px;' target='_parent'>Logout</a><br><br>";
		echo "<br><a href='logical.html' style='font-size:30px;' target='_parent'>Logout and GoTo LP CLUB Home</a>";
		echo "</body>";
		echo "</html>";
	}
	?>