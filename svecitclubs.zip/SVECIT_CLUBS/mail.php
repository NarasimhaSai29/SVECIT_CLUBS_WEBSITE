<?php
$d = $_POST["event"];
$name = $_POST["name"];
$id = $_POST["id"];
$br = $_POST["br"];
$ph = $_POST["phno"];
$email = $_POST["em"];
$subject = "SVECIT CLUBS";
$txt = "You are successfully registered for an event on $d in SVECIT clubs\n Your Name:$name\nYour ID:$id \nYour Branch is $br\nYour Phone no:$ph\nYour Email:$email";
$headers = "From: knsai208@gmail.com@gmail.com" . "\r\n" .
"CC: $email";

mail($email,$subject,$txt,$headers);
?>