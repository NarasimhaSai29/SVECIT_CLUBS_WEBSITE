<?php
	$d="";
	$d=$_POST['edate'];
	$con=mysqli_connect("localhost","root","","IT");
	if(!$con)
	{
		die("Connection failed:".mysqli_connect_error());
	}
	$re="";
	$ch="DELETE FROM wpeventslist where Date='$d'";
	if(mysqli_query($con,$ch))
	{
		echo "<html>";
		echo "<body>";
		echo "alert('Deleted suucessfully')";
		echo "<br><a href='wpeventtrig.php' style='font-size:30px;' target='_parent'>Raise Event</a><br><br>";
		echo "<br><a href='wpfaclogin.php' style='font-size:30px;' target='_parent'>Logout</a><br><br>";
		echo "<br><a href='wp.html' style='font-size:30px;' target='_parent'>Logout and GoTo WP CLUB Home</a><br><br>";
		echo "</body>";
		echo "</html>";
	}
	?>