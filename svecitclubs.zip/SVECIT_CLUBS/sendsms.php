<?php
if(isset($_POST['register']))
{
$name=$_POST['name'];
$id=$_POST['id'];
$br=$_POST['br'];
$date=$_POST['date'];
$mblno=$_POST['phno'];
$email=$_POST['em'];
	// Authorisation details.
	$username = "narasimhasai29@gmail.com";
	$hash = "7b00e75cb35fc38a56a3945f28817807768525dc2d11765bd31df9304ad7b883";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = "$mblno"; // A single number or a comma-seperated list of numbers
	$message = "You,$name  have successfully registered in SVECIT CLUB event on $date with $id from $br";
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch);
}
?>